# External Dependency Libraries

## IGraph C library tar file
igraph-0.8.0.tar.gz

This tar bundle should be unzipped and made during the R package build process controlled by the Makefile file in src.
If compiling on Windows, R will read Makefile.win first. 
This is a test starting on 8-10-23, an alternative solution would be to have all the external files
already extracted in a folder so the build process would just need the compiled static library file. 