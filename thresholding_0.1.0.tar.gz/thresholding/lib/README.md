# igraph static libraries

Destination for static libraries to be extracted into
This file ensures that R does not remove this directory upon building